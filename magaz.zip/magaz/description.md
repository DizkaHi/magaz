Magaz™️


Russia
------------------------------------------
Это первая версия магазина, не судите строго



English
------------------------------------------
This is the first version of the store, do not judge strictly





Developers ENG
------------------------------------------
Visual Designer: VL1SKKIL
Programmer: VL1SKKIL
Idea: VL1SKKIL
Assistants: Water_Melon, Acertn5252, CAMOBAPKNH



Разработчики Rus
------------------------------------------
Визуальный дизайнер: VL1SKKIL
Программист: VL1SKKIL
Идея: VL1SKKIL
Ассистенты: Water_Melon, Acertn5252, CAMOBAPKNH